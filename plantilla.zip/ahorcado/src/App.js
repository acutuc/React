import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button } from 'reactstrap';
import React, { Component } from 'react';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      imagenes:[]
    }
  }

  render() {
    return (
    <div className="App">
      <Button>Botón</Button>
    </div>
    );
  }
}
export default App;